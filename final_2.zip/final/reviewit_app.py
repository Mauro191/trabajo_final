import os
import sys
import tkinter as tk
from tkinter import messagebox, filedialog, PhotoImage

# Usuario y contraseña de ejemplo
credenciales = {".": "."}

# Diccionario con descripciones de restaurantes
descripciones = {
    "Montebello": """
    
    Montebello es un restaurante conocido por su experiencia 
    culinaria contemporánea con influencias argentinas y sudamericanas.""",
    "La Popular": """

    La Popular es un restaurante que celebra la cocina tradicional argentina,
    ofreciendo platos caseros como empanadas, milanesas y asados.""",
    "Mr. Coffe": """

    Mr. Coffe es una cafetería moderna especializada en cafés
    gourmet, pasteles artesanales y opciones veganas.""",
    "Lo + Rico": """

    Lo + Rico es un restaurante que destaca por su cocina rápida
    gourmet, con hamburguesas, papas fritas y opciones vegetarianas.""",
    "Mc Donalds": """

    McDonald's es una famosa cadena de comida rápida
    que ofrece hamburguesas, papas fritas y bebidas refrescantes.""",
    "Mostaza": """

    Mostaza es una cadena de hamburgueserías conocida por sus
    opciones variadas de hamburguesas, papas fritas y ensaladas.""",
    "Daggers": """

    Daggers es un restaurante que fusiona la cocina moderna con
    sabores internacionales, destacándose por sus carnes a la parrilla.""",
    "Oaxaca": """

    Oaxaca trae los sabores auténticos de la cocina mexicana, con
    una variedad de tacos, quesadillas y moles tradicionales.""",
    "Guapas": """

    Guapas es un restaurante mediterráneo que ofrece 
    ensaladas frescas, pastas y pescados a la parrilla.""",
    "Costumbres Argentinas": """

    Costumbres Argentinas ofrece platos típicos argentinos como 
    asados, empanadas y choripanes en un ambiente cálido y tradicional."""
}

calificaciones = {
    "Montebello": 4.2,
    "La Popular": 4.0, 
    "Mr. Coffe": 4.4, 
    "Lo + Rico": 3.2, 
    "Mc Donalds": 4.3, 
    "Mostaza": 4.1, 
    "Daggers": 4.5, 
    "Oaxaca": 3.9, 
    "Guapas": 4.0, 
    "Costumbres Argentinas": 3.8
    # Agregar calificaciones para los demás restaurantes
}

# Función para validar el login


def validar_login():
    usuario = entry_usuario.get()
    contrasena = entry_contrasena.get()
    
    if usuario in credenciales and credenciales[usuario] == contrasena:
        messagebox.showinfo("Login Exitoso", "¡Bienvenido!")
        login_window.destroy()  # Cerrar ventana de login
        abrir_pantalla_principal()  # Abrir pantalla principal
    else:
        messagebox.showerror("Error de Login", "Usuario o contraseña incorrectos")


# Función para abrir la pantalla principal
def abrir_pantalla_principal():
    # Crear la ventana principal
    ventana = tk.Tk()
    ventana.title("Reviewit App")
    ventana.geometry("1100x581+{}+{}".format(
    (ventana.winfo_screenwidth() - 1100) // 2,  # Centrado horizontal
    (ventana.winfo_screenheight() - 581) // 2  # Centrado vertical
    ))
    ventana.resizable(False, False)
    ventana.config(cursor="top_left_arrow")
    # Cargar la imagen de fondo
    # Obtén la ruta completa del archivo actual
    ruta_actual_fondo = os.path.dirname(os.path.abspath(__file__))
# Construye la ruta completa a la imagen de fondo
    ruta_fondo = os.path.join(ruta_actual_fondo, "fondo.png")
    imagen_fondo = tk.PhotoImage(file=ruta_fondo)
    # Asegúrate de que `imagen_fondo` no se elimine
    label_fondo = tk.Label(ventana, image=imagen_fondo)
    label_fondo.image = imagen_fondo  # Mantén una referencia a la imagen
    label_fondo.place(x=0, y=0, relwidth=1, relheight=1)
    imagen_fondo = ruta_fondo
    ventana.iconbitmap(ruta_icono)
   

    # Función para mostrar la reseña
    def mostrar_reseña(nombre_restaurante):
    # Obtiene la ruta absoluta al archivo actual o al ejecutable
        ruta_base_reseña = os.path.dirname(os.path.abspath(__file__))  # Cambia __file__ por sys._MEIPASS si usas PyInstaller
    # Construye la ruta relativa a la carpeta "reseñas"
        ruta_carpeta = os.path.join(ruta_base_reseña, 'reseñas')
    # Construye la ruta del archivo específico
        archivo_reseña = os.path.join(ruta_carpeta, f"{nombre_restaurante}.txt")

    # Verifica si el archivo existe
        if os.path.exists(archivo_reseña):
            with open(archivo_reseña, 'r') as file:
                contenido = file.read()
                print(contenido)  # Puedes manejar el contenido según lo que necesites
        else:
            messagebox.showerror("Error", f"No se encontró la reseña para {nombre_restaurante}")

    # Actualiza la información mostrada en la interfaz
        selected_restaurant.set(nombre_restaurante)
        actualizar_descripcion_y_calificacion(nombre_restaurante)

    # Función para actualizar la descripción y la calificación
    def actualizar_descripcion_y_calificacion(nombre_restaurante):
        descripcion = descripciones.get(nombre_restaurante, "Descripción no disponible")
        calificacion = calificaciones.get(nombre_restaurante, "Calificación no disponible")
        label_descripcion.config(text=f"Descripción del Restaurante: {descripcion}")
        label_promedio.config(text=f"Calificación Promedio: {calificacion}")

    # Función para guardar en favoritos
    def guardar_en_favoritos():
        restaurantes_favoritos = []
        for restaurante, checkbox in checkboxes.items():
            if checkbox.get():
                restaurantes_favoritos.append(restaurante)
    
        if restaurantes_favoritos:
             # Abrir el cuadro de diálogo para seleccionar la ubicación y nombre del archivo
            archivo = filedialog.asksaveasfilename(defaultextension=".txt",
                                                   filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
                                                   title="Guardar en favoritos")
        if archivo:
            try:
                with open(archivo, "a") as file:
                    for restaurante in restaurantes_favoritos:
                        # Obtener la descripción del diccionario
                        descripcion = descripciones.get(restaurante, "Descripción no disponible")
                        # Obtener el comentario del cuadro de texto
                        comentario = comentario_entry.get("1.0", tk.END).strip()
                        # Obtener la calificación del cuadro de entrada
                        calificacion = calificacion_entry.get().strip()
                        # Escribir los datos en el archivo
                        file.write(f"Restaurante: {restaurante}\n")
                        file.write(f"Descripción: {descripcion}\n")
                        file.write(f"Comentario: {comentario}\n")
                        file.write(f"Calificación: {calificacion}\n\n")

                        # Limpiar campos de entrada después de guardar 
                        comentario_entry.delete("1.0", tk.END) 
                        calificacion_entry.delete(0, tk.END)

                messagebox.showinfo("Guardado", f"Los restaurantes seleccionados han sido guardados en '{archivo}'.")
            except Exception as e:
                messagebox.showerror("Error", f"Hubo un problema al guardar en favoritos: {e}")
        else:
            messagebox.showwarning("No seleccionado", "Por favor, seleccione al menos un restaurante para guardar en favoritos.")


    # Crear un marco (frame) para el panel superior
    frame_superior = tk.Frame(ventana, background="", width=1200, height=80)
    frame_superior.grid(row=0, column=0, sticky="ew")
    frame_superior.grid_propagate(False)
    frame_superior.pack_propagate(False)

    # Crear un label (etiqueta) para el título en el panel superior
    title_label = tk.Label(frame_superior, text="Reviewit App - Reseñas", font=("Comic Sans MS", 20), bg="papaya whip",bd=5, highlightthickness=4, highlightbackground = "FireBrick4", highlightcolor= "FireBrick4")
    title_label.pack(pady=18)

    # Crear un marco (frame) para el panel inferior
    frame_bottom = tk.Frame(ventana, background="", width=1200, height=510)
    frame_bottom.grid(row=1, column=0, sticky="nsew")
    frame_bottom.grid_propagate(False)
    frame_bottom.pack_propagate(False)

    # Crear dos sub-paneles dentro del panel inferior, uno al lado del otro
    frame_left = tk.Frame(frame_bottom, width=260, height=480, bg="FireBrick4", bd=5, relief="raised")
    frame_left.grid(row=0, column=0,padx=30, pady=3 , sticky="nsew")
    frame_left.pack_propagate(False)
#
    frame_right = tk.Frame(frame_bottom, width=740, height=80, bg="papaya whip", bd=5, highlightthickness=4, highlightbackground = "FireBrick4", highlightcolor= "FireBrick4")
    frame_right.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
    frame_right.grid_propagate(False)
    frame_right.pack_propagate(False)
    # Lista de restaurantes
    restaurantes = [
        "Montebello", "La Popular", "Mr. Coffe", "Lo + Rico", "Mc Donalds",
        "Mostaza", "Daggers", "Oaxaca", "Guapas", "Costumbres Argentinas"
    ]

    # Diccionario para almacenar las casillas de verificación de cada restaurante
    checkboxes = {}
    selected_restaurant = tk.StringVar()

    for restaurante in restaurantes:
        row_frame = tk.Frame(frame_left, bg="FireBrick4")
        row_frame.pack(fill=tk.X, padx=10, pady=3)
        var = tk.BooleanVar()
        checkbox = tk.Checkbutton(row_frame, variable=var, bg="FireBrick4")
        checkbox.pack(side=tk.LEFT, padx=5)
        boton = tk.Button(row_frame, text=restaurante, width=30, height=2, bg="papaya whip", font=("Courier",9) , command=lambda r=restaurante: mostrar_reseña(r))
        boton.pack(side=tk.LEFT, padx=5)
        checkboxes[restaurante] = var

    label_descripcion = tk.Label(frame_right, text="Descripción del Restaurante", font=("Comic Sans MS", 15), bg="papaya whip")
    label_descripcion.pack(pady=8)

    label_promedio = tk.Label(frame_right, text="Calificación Promedio: ", font=("Comic Sans MS", 15), bg="papaya whip")
    label_promedio.pack(pady=6)

    comentario_label = tk.Label(frame_right, text="Por favor, deje aquí su comentario", font=("Comic Sans MS", 14), bg="papaya whip")
    comentario_label.pack(pady=(10, 0))
    comentario_entry = tk.Text(frame_right, width=60, height=4, highlightthickness=1, highlightbackground = "black", highlightcolor= "black")
    comentario_entry.pack(pady=10)

    calificacion_label = tk.Label(frame_right, text="Por favor, marque del 1 al 5 el puntaje que le daría a este restaurante", font=("Comic Sans MS", 14), bg="papaya whip")
    calificacion_label.pack(pady=(10, 0))
    calificacion_entry = tk.Entry(frame_right, width=5, highlightthickness=1, highlightbackground = "black", highlightcolor= "black")
    calificacion_entry.pack(pady=10)

    boton_guardar = tk.Button(frame_right, text="Guardar en favoritos", font=("Comic Sans MS", 14), bg="bisque2", command=guardar_en_favoritos , cursor="plus" )
    boton_guardar.pack(pady=10)

    ventana.mainloop()

##########################    VENTANA DE LOGIN    ######################################
login_window = tk.Tk()
# Obtén la ruta completa del archivo actual
ruta_actual = os.path.dirname(os.path.abspath(__file__))

# Construye la ruta del archivo de icono
ruta_icono = os.path.join(ruta_actual, "icono.ico")

# Configura el ícono usando la ruta absoluta
login_window.iconbitmap(ruta_icono)
# Crear la ventana de login

login_window.title("Login")
login_window.geometry("300x200+{}+{}".format(
    (login_window.winfo_screenwidth() - 300) // 2,  # Centrado horizontal
    (login_window.winfo_screenheight() - 200) // 2  # Centrado vertical
    ))

login_window.config(cursor="top_left_arrow")
login_window.config(background="FireBrick4", highlightthickness = 2, highlightbackground = "goldenrod1", highlightcolor = "goldenrod1")

# Etiqueta y campo de entrada para el usuario
label_usuario = tk.Label(login_window, text="Usuario:", font= "Courier", background="FireBrick4")
label_usuario.pack(pady=5)
entry_usuario = tk.Entry(login_window, highlightthickness = 1, highlightbackground = "goldenrod1", highlightcolor = "goldenrod1")
entry_usuario.pack(pady=5)

# Etiqueta y campo de entrada para la contraseña
label_contrasena = tk.Label(login_window, text="Contraseña:", font= "Courier", background="FireBrick4")
label_contrasena.pack(pady=5)
entry_contrasena = tk.Entry(login_window, show="*", highlightthickness = 1, highlightbackground = "goldenrod1", highlightcolor = "goldenrod1")
entry_contrasena.pack(pady=5)

# Botón de Login
boton_login = tk.Button(login_window, text="Login", command=validar_login)
boton_login.pack(pady=20)

# Ejecutar la ventana de login
login_window.mainloop()

def obtener_ruta_recurso(ruta_relativa):
    """Obtiene la ruta absoluta al recurso (compatible con PyInstaller)."""
    if hasattr(sys, '_MEIPASS'):
        # Cuando se ejecuta desde el .exe
        base_path = sys._MEIPASS
    else:
        # Cuando se ejecuta directamente desde Python
        base_path = os.path.abspath(".")
    return os.path.join(base_path, ruta_relativa)